import deck from "./deck.js";

// console.log("deck", deck);
let localDeck = Array.from(deck);
let reducedLocalDeck = [];
let anzahl = 0;

export function neuesBoard() {
  let board = [];
  let i = 5;

  // console.log("", localDeck);

  while (i--) {
    let zz = Math.floor(Math.random() * localDeck.length);
    board.push(localDeck[zz]);
    localDeck.splice(zz, 1);
  }

  // console.log("", localDeck);
  checkIfCardsAreAvailable();
  document.getElementById(
    "restKarten"
  ).innerHTML = `Restkarten ${localDeck.length}`;
  reducedLocalDeck = localDeck;

  localDeck = Array.from(deck);

  return board;
}

export function neuerFlop() {
  let flop = [];
  let i = 3;

  while (i--) {
    let zz = Math.floor(Math.random() * localDeck.length);
    flop.push(localDeck[zz]);
    localDeck.splice(zz, 1);
  }
  checkIfCardsAreAvailable;
  document.getElementById(
    "restKarten"
  ).innerHTML = `Restkarten ${localDeck.length}`;
  reducedLocalDeck = localDeck;

  localDeck = Array.from(deck);
  return flop;
}

export function neuerTurn() {
  let turn = [];
  let i = 1;

  if (reducedLocalDeck.length === 0) {
    reducedLocalDeck = localDeck;
  }

  while (i--) {
    let zz = Math.floor(Math.random() * reducedLocalDeck.length);
    turn.push(localDeck[zz]);
    reducedLocalDeck.splice(zz, 1);
  }
  checkIfCardsAreAvailable();
  document.getElementById(
    "restKarten"
  ).innerHTML = `Restkarten ${reducedLocalDeck.length}`;

  return turn;
}

export function neuerRiver() {
  let river = [];
  let i = 1;

  if (reducedLocalDeck.length === 0) {
    reducedLocalDeck = localDeck;
  }

  while (i--) {
    let zz = Math.floor(Math.random() * reducedLocalDeck.length);
    river.push(reducedLocalDeck[zz]);
    reducedLocalDeck.splice(zz, 1);
  }

  checkIfCardsAreAvailable();
  document.getElementById(
    "restKarten"
  ).innerHTML = `Restkarten ${reducedLocalDeck.length}`;

  return river;
}

function checkIfCardsAreAvailable() {
  if (deck.length === 0) {
    addEventListener("click", () => {
      location.reload();
    });
  }
  return;
}

export { reducedLocalDeck, localDeck };
