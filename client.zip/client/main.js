import {
  neuesBoard,
  neuerTurn,
  neuerRiver,
  neuerFlop,
  reducedLocalDeck, // diese variable müsste sich dynamisch aus dem Modul kartenDealen.js ändern damit holeCards unabhängig von den Boardkarten erstellt werden können
  localDeck,
} from "./kartenDealen.js";

import { alleKartenDarstellen } from "./alleKartenDarstellen.js";

import tischLayout from "./tischLayout.js";
import { imgIdOmaha, imgIdTexas } from "./tischLayout.js";

import { findBoard } from "./findBoard.js";

let board = [];
let turn = [];
let river = [];
let flop = [];
let holeCards = [];

let imgFlop0 = document.getElementsByClassName("flop")[0];
let imgFlop1 = document.getElementsByClassName("flop")[1];
let imgFlop2 = document.getElementsByClassName("flop")[2];
let imgTurn = document.getElementById("turn");
let imgRiver = document.getElementById("river");

document.getElementById("btn-neuesBoard").addEventListener("click", () => {
  board = neuesBoard();
  imgFlop0.src = `../cards/${board[0]}.png`;
  imgFlop1.src = `../cards/${board[1]}.png`;
  imgFlop2.src = `../cards/${board[2]}.png`;
  imgTurn.src = `../cards/${board[3]}.png`;
  imgRiver.src = `../cards/${board[4]}.png`;
});

document.getElementById("btn-neuerFlop").addEventListener("click", () => {
  flop = neuerFlop();
  console.log(flop);
  imgFlop0.src = `../cards/${flop[0]}.png`;
  imgFlop1.src = `../cards/${flop[1]}.png`;
  imgFlop2.src = `../cards/${flop[2]}.png`;
  imgTurn.src = `../cards/blank.png`;
  imgRiver.src = `../cards/blank.png`;
});

document.getElementById("btn-turn").addEventListener("click", () => {
  turn = neuerTurn();
  console.log(turn);
  imgTurn.src = `../cards/${turn}.png`;
});

document.getElementById("btn-river").addEventListener("click", () => {
  river = neuerRiver();
  imgRiver.src = `../cards/${river}.png`;
});

document.getElementById("btn-holeCards").addEventListener("click", () => {
  createHoleCards(
    Number(document.getElementById("countPlayers").value),
    aktuelleSpielVariante
  );
});

window.tischLayout = tischLayout;

alleKartenDarstellen();

let aktuelleSpielVariante = "";

function setToOmaha() {
  aktuelleSpielVariante = "o";
  console.log("", "o");
}

function setToTexas() {
  aktuelleSpielVariante = "t";
  console.log("", "t");
}

document.getElementById("texas").addEventListener("click", setToTexas);
document.getElementById("omaha").addEventListener("click", setToOmaha);

function createHoleCards(anzahlSpieler, statusSpielVariante) {
  console.log("", statusSpielVariante);

  if (statusSpielVariante === "") {
    alert("Bitte Spiel Texas oder Omaha wählen");
    return;
  }

  if (reducedLocalDeck.length === 0) {
    reducedLocalDeck = localDeck;
  }

  console.log("", reducedLocalDeck);
  console.log("", typeof reducedLocalDeck);
  console.log("", localDeck);

  console.log("", imgIdTexas);
  let spielVariante;

  statusSpielVariante === "o" ? (spielVariante = 4) : (spielVariante = 2);

  let i = anzahlSpieler * spielVariante;
  console.log("", i);
  holeCards = [];
  while (i--) {
    let zz = Math.floor(Math.random() * reducedLocalDeck.length);
    holeCards.push(reducedLocalDeck[zz]);
    reducedLocalDeck.splice(zz, 1);
  }
  console.log("", holeCards);

  if (statusSpielVariante === "o") {
    //
    let i = 0;
    while (imgIdOmaha.length > 0) {
      document.getElementById(
        imgIdOmaha[0]
      ).src = `../cards/${holeCards[i]}.png`;

      imgIdOmaha.splice(0, 1);
      i++;
    }
  } else {
    let i = 0;
    while (imgIdTexas.length > 0) {
      document.getElementById(
        imgIdTexas[0]
      ).src = `../cards/${holeCards[i]}.png`;

      imgIdTexas.splice(0, 1);
      i++;
    }
  }

  return;
}
